package com.example.serviciosmartins.repo

import com.example.serviciosmartins.data.ServiceDao
import com.example.serviciosmartins.data.ServiceEntity
import kotlinx.coroutines.flow.Flow

class ServiceRepository(
    private val dao: ServiceDao
) {
    fun observeAll(): Flow<List<ServiceEntity>> = dao.observeAll()

    suspend fun getById(id: Long): ServiceEntity? = dao.getById(id)

    suspend fun insert(entity: ServiceEntity): Long = dao.insert(entity)

    suspend fun update(entity: ServiceEntity) = dao.update(entity)

    suspend fun delete(entity: ServiceEntity) = dao.delete(entity)
}
