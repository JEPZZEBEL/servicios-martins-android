package com.example.serviciosmartins.ui.theme

import androidx.compose.ui.graphics.Color

val BgBlack = Color(0xFF0B0F14)
val PanelBlack = Color(0xFF101823)
val CardBlack = Color(0xFF0F1620)

val SkyBlue = Color(0xFF66D9FF)
val SkyBlueSoft = Color(0xFF9BE8FF)

val TextSoft = Color(0xFFB7C4D3)
val TextMuted = Color(0xFF7F8FA3)

val Danger = Color(0xFFFF5C5C)
val Success = Color(0xFF3DFFB5)
