package com.example.serviciosmartins.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.serviciosmartins.data.ServiceEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesScreen(
    vm: ServicesViewModel,
    onOpenDetail: (Long) -> Unit
) {
    val services by vm.services.collectAsState()

    var query by rememberSaveable { mutableStateOf("") }

    // Bottom sheet
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ServiceEntity?>(null) }

    var title by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("") }
    var desc by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }

    fun openCreate() {
        editing = null
        title = ""
        category = ""
        desc = ""
        phone = ""
        showForm = true
    }

    fun openEdit(s: ServiceEntity) {
        editing = s
        title = s.title
        category = s.category
        desc = s.description
        phone = s.phone
        showForm = true
    }

    val filtered = remember(services, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) services
        else services.filter {
            it.title.lowercase().contains(q) ||
                    it.category.lowercase().contains(q) ||
                    it.description.lowercase().contains(q) ||
                    it.phone.lowercase().contains(q)
        }
    }

    if (showForm) {
        ModalBottomSheet(
            onDismissRequest = { showForm = false }
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = if (editing == null) "Nuevo servicio" else "Editar servicio",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Título") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Categoría (Ej: Electricidad)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Descripción") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Teléfono") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(Modifier.height(14.dp))

                Button(
                    onClick = {
                        val t = title.trim()
                        val c = category.trim()
                        val d = desc.trim()
                        val p = phone.trim()

                        if (t.length < 3 || c.length < 3 || d.length < 5 || p.length < 6) return@Button

                        val e = editing
                        if (e == null) {
                            vm.addService(t, c, d, p)
                        } else {
                            vm.updateService(
                                e.copy(
                                    title = t,
                                    category = c,
                                    description = d,
                                    phone = p
                                )
                            )
                        }
                        showForm = false
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (editing == null) "GUARDAR SERVICIO" else "ACTUALIZAR SERVICIO")
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Servicios Martins") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { openCreate() }) {
                Icon(Icons.Default.Add, contentDescription = "Agregar")
            }
        }
    ) { padding ->

        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Buscar") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = "Total: ${filtered.size}",
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                Text("No hay servicios todavía.")
                Text("Presiona + para crear tu primer registro.")
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(filtered, key = { it.id }) { s ->
                        ServiceCard(
                            service = s,
                            onOpen = { onOpenDetail(s.id) },
                            onEdit = { openEdit(s) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceCard(
    service: ServiceEntity,
    onOpen: () -> Unit,
    onEdit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors()
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                text = service.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(4.dp))
            Text(text = "Categoría: ${service.category}")
            Spacer(Modifier.height(4.dp))
            Text(text = service.description, maxLines = 2)
            Spacer(Modifier.height(8.dp))

            androidx.compose.foundation.layout.Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(onClick = onEdit, modifier = Modifier.weight(1f)) {
                    Text("Editar")
                }
                IconButton(onClick = onOpen) {
                    Icon(Icons.Default.ArrowForward, contentDescription = "Ver detalle")
                }
            }
        }
    }
}
