package com.example.serviciosmartins.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.serviciosmartins.data.ServiceEntity
import com.example.serviciosmartins.repo.ServiceRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ServicesViewModel(
    private val repo: ServiceRepository
) : ViewModel() {

    // ✅ Esto alimenta la lista en tiempo real
    val services: StateFlow<List<ServiceEntity>> =
        repo.observeAll()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addService(title: String, category: String, desc: String, phone: String) {
        val t = title.trim()
        val c = category.trim()
        val d = desc.trim()
        val p = phone.trim()

        if (t.length < 3 || c.length < 3 || d.length < 5 || p.length < 6) return

        viewModelScope.launch(Dispatchers.IO) {
            repo.insert(
                ServiceEntity(
                    title = t,
                    category = c,
                    description = d,
                    phone = p
                )
            )
        }
    }

    fun updateService(entity: ServiceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.update(entity)
        }
    }

    fun deleteService(entity: ServiceEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repo.delete(entity)
        }
    }
}
