package com.example.serviciosmartins.repo

import com.example.serviciosmartins.data.RequestDao
import com.example.serviciosmartins.data.RequestEntity
import kotlinx.coroutines.flow.Flow

class RequestRepository(
    private val dao: RequestDao
) {
    val requests: Flow<List<RequestEntity>> = dao.observeAll()

    suspend fun insert(entity: RequestEntity) = dao.insert(entity)
    suspend fun update(entity: RequestEntity) = dao.update(entity)
    suspend fun delete(entity: RequestEntity) = dao.delete(entity)
    suspend fun getById(id: Long): RequestEntity? = dao.getById(id)
}
