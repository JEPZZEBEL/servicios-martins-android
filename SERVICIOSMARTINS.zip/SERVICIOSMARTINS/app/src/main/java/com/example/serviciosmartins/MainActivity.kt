package com.example.serviciosmartins

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.serviciosmartins.ui.AppNav
import com.example.serviciosmartins.ui.theme.SERVICIOSMARTINSTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SERVICIOSMARTINSTheme {
                AppNav()
            }
        }
    }
}
