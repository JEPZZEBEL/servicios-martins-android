package com.example.serviciosmartins.ui.theme

import androidx.compose.material3.Typography
val Typography = Typography()
