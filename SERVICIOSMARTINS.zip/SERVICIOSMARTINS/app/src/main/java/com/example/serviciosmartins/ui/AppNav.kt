package com.example.serviciosmartins.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.serviciosmartins.data.AppDatabase
import com.example.serviciosmartins.repo.ServiceRepository

@Composable
fun AppNav() {
    val navController = rememberNavController()
    val ctx = LocalContext.current

    val db = AppDatabase.get(ctx)
    val repo = ServiceRepository(db.serviceDao())

    val servicesVm: ServicesViewModel = viewModel(
        factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return ServicesViewModel(repo) as T
            }
        }
    )

    Scaffold { inner ->
        NavHost(
            navController = navController,
            startDestination = "services",
            modifier = Modifier.padding(inner)
        ) {
            composable("services") {
                ServicesScreen(
                    vm = servicesVm,
                    onOpenDetail = { id -> navController.navigate("detail/$id") }
                )
            }

            composable("detail/{id}") { backStack ->
                val id = backStack.arguments?.getString("id")?.toLongOrNull() ?: 0L
                DetailScreen(
                    id = id,
                    vm = servicesVm,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
